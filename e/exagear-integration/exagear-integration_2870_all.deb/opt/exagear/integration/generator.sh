#!/bin/bash
# Copyright (c) 2019 Huawei Technologies Co., Ltd. All rights reserved.
#
# This script s  triggered by exagear-guest-service.sh which is located in /lib/systemd/system-generators/ directory
# and, in turn, is triggered at early boot stage for generate on-the-fly systemd units.
# Purpose of this script is to 'mirror' all guest systemd service in host.
# This script walks over all systemd config directories in all installed guest images and copies systemd services located there to /run/systemd
# directory. It's not just a copy: all entries that contain launchable commands are wrapped with exagear and some paths are converted.
# converter.sh scripts is responsible for that convertation.

# Guest services shoudln't mask host ones with same name so we place generated units in 'late' dir.

LATE_DIR=${3}
ALL_GUEST_IMAGES=`find /opt/exagear/images/ -maxdepth 1 -mindepth 1 -type d -exec basename {} \;`

function is_native_service {
    SRV=${1}
    for NS in ${NATIVE_SERVICES}
    do
        if [ "${GUEST_ROOT}/${NS}" == "${SRV}" ]
        then
            return 0
        fi
    done
    return 1
}

for GUEST_IMAGE in ${ALL_GUEST_IMAGES}
do
    GUEST_ROOT="/opt/exagear/images/${GUEST_IMAGE}"
    NATIVE_SERVICES=`cat ${GUEST_ROOT}/.exagear/native-systemd-services`

    GUEST_CONFIG="/etc/exagear-guest-for-${GUEST_IMAGE}.conf"
    if [ ! -f ${GUEST_CONFIG} ]
    then
        continue
    fi

    . ${GUEST_CONFIG}

    if [ ${GUEST_IMAGE} != ${EXAGEAR_GUEST_IMAGE_NAME} ]
    then
        continue
    fi

    CORE_CONFIG=/etc/exagear-${EXAGEAR_IMAGE_ARCH}.conf

    SYSV_TDIR=`mktemp -d -p ${LATE_DIR}`

    # Launch all generators in guest. Output of guest generators will be consumed
    # by guest->host systemd service converter. Generators will place their output
    # in ${SYSV_TDIR} - a temporary dir created specially for guest generators.
    # It will be deleted after its contents will be converted to host ones.
    GUEST_GENERATORS_DIRS="${GUEST_ROOT}/lib/systemd/system-generators/"

    if [ "`readlink -f ${GUEST_ROOT}/lib`" != "${GUEST_ROOT}/usr/lib" ]; then
        GUEST_GENERATORS_DIRS="${GUEST_GENERATORS_DIRS} ${GUEST_ROOT}/usr/lib/systemd/system-generators/"
    fi

    GUEST_GENERATORS="`find ${GUEST_GENERATORS_DIRS} -maxdepth 1 -type f 2>/dev/null`"

    for GEN in ${GUEST_GENERATORS}
    do
        GEN_GUEST_PATH="${GEN:${#GUEST_ROOT}:${#GEN}}"

        EXAGEAR_CORE_CONF=${CORE_CONFIG} EXAGEAR_GUEST_CONF=${GUEST_CONFIG} \
        /opt/exagear/bin/ubt-wrapper ${GEN_GUEST_PATH} ${SYSV_TDIR} ${SYSV_TDIR} \
                                     ${SYSV_TDIR}
    done

    ALL_SYSTEMD_DIRS="${GUEST_ROOT}/lib/systemd/system \
                      ${GUEST_ROOT}/etc/systemd/system/ \
                      ${SYSV_TDIR}"

    if [ "`readlink -f ${GUEST_ROOT}/lib`" != "${GUEST_ROOT}/usr/lib" ]; then
        ALL_SYSTEMD_DIRS="${GUEST_ROOT}/usr/lib/systemd/system ${ALL_SYSTEMD_DIRS}"
    fi

    for SYSTEM_DIR in ${ALL_SYSTEMD_DIRS}
    do
        SYSTEMD_SERVICES=`find ${SYSTEM_DIR} -maxdepth 1 -type f `

        for SERVICE in ${SYSTEMD_SERVICES}
        do
            if is_native_service ${SERVICE}
            then
                continue
            fi
            TARGET_FILE="${LATE_DIR}/`basename ${SERVICE}`"
            /opt/exagear/integration/converter.sh ${SERVICE} ${TARGET_FILE} \
                                                  /etc/exagear-${EXAGEAR_IMAGE_ARCH}.conf \
                                                  ${GUEST_CONFIG}
        done
    done

    for SYSTEM_DIR in ${ALL_SYSTEMD_DIRS}
    do
        TARGET_WANTS=`find ${SYSTEM_DIR} -maxdepth 1 -type d -name "*.target.wants"`
        for TARGET in ${TARGET_WANTS}
        do
            ALL_WANTS=`find ${TARGET} -maxdepth 1 -type l`
            for WANT in ${ALL_WANTS}
            do
                if [ -e "${LATE_DIR}/`basename ${WANT}`" ]
                then
                    mkdir -p ${LATE_DIR}/`basename ${TARGET}`
                    ln -sf "${LATE_DIR}/`basename ${WANT}`" "${LATE_DIR}/`basename ${TARGET}`/`basename ${WANT}`"
                fi
            done
        done
    done

    rm -rf ${SYSV_TDIR}
done
