<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1">
<context>
    <name>main</name>
    <message>
        <location filename="../main.qml" line="15"/>
        <source>Title height</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main.qml" line="16"/>
        <source>Change window title height</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main.qml" line="78"/>
        <source>Reset to default</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main.qml" line="92"/>
        <source>Apply</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
