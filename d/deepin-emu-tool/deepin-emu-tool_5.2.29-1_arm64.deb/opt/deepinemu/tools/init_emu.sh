#!/bin/bash

def_name="box86"
SUPPORT_EMU_NAMES=($def_name exagear)

get_value()
{
    cat /opt/apps/$1/files/run.sh | grep "$2=" | awk -F = '{print $NF}' | awk -F \" '{print $2}'
}

format_emu_name()
{
    for name in ${SUPPORT_EMU_NAMES[@]};do
        if [ "$1" = "$name" ];then
            echo $1
            return
        fi
    done

    echo $def_name
}

check_unsupport_x86()
{
    ## 检查exagear是否能够运行x86程序
    $EXAGEAR_CMD $EXAGEAR_ARGS $IMAGE_PATH/usr/bin/dirname "$IMAGE_PATH" &> /dev/null
    if [ $? != 0 ];then
        # 不能echo 输出，会干扰结果的输出
        return 0
    else
        return 1
    fi
}

check_unsupport_arm32()
{
    /opt/deepinemu/tools/isLinux32 &> /dev/null
    CHECK_ARM32=$?

    if [[ $CHECK_ARM32 != 1 ]];then
        # 不能echo 输出，会干扰结果的输出
        return 0
    else
        return 1
    fi
}

emu_count()
{
    echo $#
}

support_emu_name()
{
    # TODO 目前假定只有两种模拟器的情况，只有二选一，没有判断两个都不支持的情况
    if check_unsupport_x86 ;then
        # 如果不支持通过exagear运行x86二进制，如飞腾的CPU只能用box86
        echo "box86"
        return
    elif check_unsupport_arm32 ;then
        # 鲲鹏920环境只能用exagear
        echo "exagear"
        return
    fi

    echo ${SUPPORT_EMU_NAMES[*]}
}

user_emu_name()
{
    support_names=$(support_emu_name)
    support_count=$(emu_count $support_names)

    init_emu_config

    if [ "$support_count" = 1 ];then
        # 如果当前环境只支持一种模拟器，则不考虑用户设置的模拟器
        echo $support_names
    elif [ -f "$EMU_CONFIG" ];then
        # 支持用户配置使用的模拟器，都支持的情况优先用容器目录配置的模拟器
        emu_name=$(cat "$EMU_CONFIG")
        format_emu_name $emu_name
        # TODO 目前假定只有两种模拟器的情况，没有考虑设置模拟器不在支持模拟器列表中的情况
    fi
}

init_emu_name()
{
    ## 打包通过DEF_EMU_NAME环境变量指定优先使用的模拟器
    ## 1、 不支持exagear情况用box86
    ## 2、 不支持box86的情况用exagear
    ## 3、 都支持的情况使用容器配置的模拟器
    ## 4、 用户环境没有配置则用应用配置的模拟器,
    ## 5、 应用没有配置用box86

    # 优先根据用户环境选择模拟器
    EMU_NAME=$(user_emu_name)

    # 用户环境没有指定模拟器，则通过打包脚本指定模拟器是用box86还是exager
    if [ -z "$EMU_NAME" ];then
        EMU_NAME="$DEF_EMU_NAME"
    fi

    if [ -z "$EMU_NAME" ];then
        # 以上方式都没有指定则用box86
        EMU_NAME="$def_name"
    fi

    echo "use $EMU_NAME as emulator"
}

init_emu_config()
{
    if [ -z "$WINEPREFIX" ];then
        if [ -f "/opt/apps/$1/files/run.sh" ];then
            BOTTLE_NAME=$(get_value $1 BOTTLENAME)
            WINEPREFIX="$HOME/.deepinwine/$BOTTLE_NAME"
        else
            echo "WINEPREFIX未指定，请指定WINEPREFIX变量"
            exit
        fi
    fi

    EMU_CONFIG="$WINEPREFIX/.emu_name"
}

choose_emu()
{
    if [ -f "/opt/deepin-box86/init_box86.sh" ];then
        source /opt/deepin-box86/init_box86.sh
    fi

    if [ -f "/opt/exagear/init_exagear.sh" ];then
        source /opt/exagear/init_exagear.sh
    fi

    init_emu_name

    if [ "$EMU_NAME" = "exagear" ];then
        export WINESERVERNAME="wineserver64"
        export EMU_CMD="$EXAGEAR_CMD"
        export EMU_ARGS="$EXAGEAR_ARGS"
        export LC_ALL=zh_CN.UTF-8
    else
        if [ -f "$BOX86_EMU_CMD" ];then
            export EMU_CMD="$BOX86_EMU_CMD"
        else
            export EMU_CMD="$BOX86_CMD"
        fi
        unset EMU_ARGS

        runtime_path=/opt/deepinwine/runtime-i386
        if [ -f "$runtime_path/init_runtime.sh" ];then
            source "$runtime_path/init_runtime.sh"
            init_box86_runtime
        fi
    fi

    echo "emu command line: $EMU_CMD $EMU_ARGS"
}

list_emu_names()
{
    list_head="support emu names:"
    init_emu_config $1

    # 当前系统环境支持的模拟器列表
    support_names=$(support_emu_name)
    support_count=$(emu_count $support_names)
    first_emu=$(echo $support_names | awk '{print $1}')

    if [ $support_count -eq 1 ];then
        # 如果当前环境只支持一种模拟器，则不考虑用户设置的模拟器
        echo "$list_head $support_names"
        return
    elif [ -f "$EMU_CONFIG" ];then
        # 如果容器目录有配置则，第一个位置输出用户配置的模拟器，方便在界面显示当前配置的模拟器
        EMU_NAME=$(cat "$EMU_CONFIG")
    elif [ -f "/opt/apps/$1/files/run.sh" ];then
        EMU_NAME=$(get_value $1 DEF_EMU_NAME)
    fi

    if [ -z "$EMU_NAME" ];then
        # 用户没有指定模拟器直接输出所有支持的模拟器
        echo "$list_head $support_names"
    elif [ "$EMU_NAME" = "$first_emu" ];then
        # 指定的模拟器就是列表中的第一位
        echo "$list_head $support_names"
    else
        # 指定模拟器不在列表第一位，需要把列表重新排序输出
        # TODO 目前假定只有两种模拟器，简化排序逻辑
        echo "$list_head $EMU_NAME $first_emu"
    fi
}

set_emu_name()
{
    /opt/apps/$2/files/run.sh -c
    init_emu_config $2

    EMU_NAME=$(format_emu_name $1)
    if [ -d "$WINEPREFIX" ];then
        echo "$EMU_NAME" > "$EMU_CONFIG"
    else
        echo "WINEPREFIX: $WINEPREFIX 目录不存在"
    fi
}

if [ "$1" == "-l" ];then
    list_emu_names $2
elif [ "$1" == "-s" ];then
    set_emu_name $2 $3
elif [ "$1" == "-h" ];then
    echo "列举应用支持的模拟器: ./init_emu.sh -l package_name"
    echo "设置应用使用的模拟器: ./init_emu.sh -s emu_name package_name"
else
    choose_emu
fi
