<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1">
<context>
    <name>Actions</name>
    <message>
        <location filename="../Actions.qml" line="19"/>
        <source>Shutdown</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Actions.qml" line="26"/>
        <source>Reboot</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Actions.qml" line="33"/>
        <source>Lock</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Actions.qml" line="40"/>
        <source>Logout</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>main</name>
    <message>
        <location filename="../main.qml" line="12"/>
        <source>Automate Tasks</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main.qml" line="13"/>
        <source>Visual configuration automatically executes actions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main.qml" line="27"/>
        <source>after</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main.qml" line="39"/>
        <source>minutes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main.qml" line="45"/>
        <source>perform</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main.qml" line="54"/>
        <source>operation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main.qml" line="59"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main.qml" line="59"/>
        <source>Start</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main.qml" line="76"/>
        <source>%1 after %2:%3, please do not leave this UI.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
