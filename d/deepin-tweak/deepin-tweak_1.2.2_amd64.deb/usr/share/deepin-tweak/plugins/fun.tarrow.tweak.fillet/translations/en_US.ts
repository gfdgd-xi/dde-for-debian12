<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1">
<context>
    <name>main</name>
    <message>
        <location filename="../main.qml" line="14"/>
        <source>Fillet size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main.qml" line="15"/>
        <source>Adjust window fillet size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main.qml" line="41"/>
        <source>Fillet size (0-18)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main.qml" line="67"/>
        <source>Reset to default</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main.qml" line="86"/>
        <source>Apply</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
