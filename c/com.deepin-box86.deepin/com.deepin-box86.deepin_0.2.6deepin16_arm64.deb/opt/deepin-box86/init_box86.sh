#!/bin/bash

BOX86_CMD="/opt/deepin-box86/box86"
