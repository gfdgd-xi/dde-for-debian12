#!/bin/bash 
# Copyright (c) 2019 Huawei Technologies Co., Ltd. All rights reserved.
#
# This script is triggered by generator.sh script. It's responsible for converting a guest systemd unit file into a host one.
# It performs some convertations:
# - adds prefix "/opt/exagear/image/<image-name>" to all paths in unit file
# - adds prefix "/opt/exagear/bin/ubt-wrapper" to all launchable commands in unit file

FROM=${1}
TO=${2}
#Config file that points to which exagear binary should be launched
EXAGEAR_CORE_CONF=${3}
#Config file that points to guest image
EXAGEAR_GUEST_CONF=${4}

. ${EXAGEAR_GUEST_CONF}

if [ -z ${FROM} ] || [ -z ${TO} ]
then
    echo "Usage: $0 <from> <to> <core config> <guest config>"
    exit 1
fi

cat ${FROM} > ${TO}

SYSTEMD_EXECUTABLE_ENTRY="\
ExecStartPre \
ExecStartPost \
ExecStart \
ExecReload \
ExecStop"

for E in ${SYSTEMD_EXECUTABLE_ENTRY}
do
    sed -i -E "s/${E}=-?/${E}=-\/opt\/exagear\/bin\/ubt-wrapper /g" ${TO}
done

GUEST_PATH_ENTRY="\
SourcePath"

for E in ${GUEST_PATH_ENTRY}
do
    sed -i -E "s/${E}=/${E}=\/opt\/exagear\/images\/${EXAGEAR_IMAGE_NAME}/g" ${TO}
done

#This is needed if FROM file doesn't have '\n' at end
echo -e  "\n" >> ${TO}

echo "[Service]" >> ${TO}
echo "Environment=EXAGEAR_CORE_CONF=${EXAGEAR_CORE_CONF}" >> ${TO}
echo "Environment=EXAGEAR_GUEST_CONF=${EXAGEAR_GUEST_CONF}" >> ${TO}
echo "#${EXAGEAR_GUEST_WRAP_MARKER}" >> ${TO}
