#!/bin/bash

EXAGEAR_CMD="/opt/exagear/exagear-wrapper.sh"
