#!/bin/bash -e
# Copyright (c) 2019 Huawei Technologies Co., Ltd. All rights reserved.
#
# This script is triggered by systemd at generators stage (man systemd.generator)
# It's an entry point into guest -> host systemd service forwarding subsystem
# See description of underlying scripts for details of systemd forwarding mechanism.

exec /opt/exagear/integration/generator.sh $@
