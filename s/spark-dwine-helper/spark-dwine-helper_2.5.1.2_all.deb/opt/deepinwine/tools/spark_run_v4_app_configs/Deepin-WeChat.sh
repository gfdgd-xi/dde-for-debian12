    export DISABLE_RENDER_CLIPBOARD=1
    CallProcess "$@"
