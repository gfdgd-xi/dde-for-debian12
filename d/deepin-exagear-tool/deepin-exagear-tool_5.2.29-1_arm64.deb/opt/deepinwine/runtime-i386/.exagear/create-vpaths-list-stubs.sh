#!/bin/bash -e

IMAGE_DIR="/opt/deepinwine/runtime-i386"
VPATHS_LIST="${IMAGE_DIR}/.exagear/vpaths-list"
if [ ! -f "${VPATHS_LIST}" ]
then
    echo "Error: vpaths-list is not found"
    exit 1
fi

cat "${VPATHS_LIST}" | while read ENTRY;
do   
        if [ ! -z "${ENTRY}" ]
        then
            if  [ "`echo $ENTRY | tail -c 2`" == '/' ]
            then            
                mkdir -p "/${IMAGE_DIR}/${ENTRY}"
            else
                mkdir -p `dirname "/${IMAGE_DIR}/${ENTRY}"`

                if [ -L "/${IMAGE_DIR}/${ENTRY}" ]
                then
                    unlink "/${IMAGE_DIR}/${ENTRY}"
                fi

                if [ -e "/${IMAGE_DIR}/${ENTRY}" ]
                then
                    truncate --size 0 "/${IMAGE_DIR}/${ENTRY}"
                else
                    touch "/${IMAGE_DIR}/${ENTRY}"
                fi
            fi
        fi
done
exit 0


