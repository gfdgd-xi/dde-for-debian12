<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="zh_CN">
<context>
    <name>main</name>
    <message>
        <source>Title height</source>
        <translation type="vanished">标题栏高度</translation>
    </message>
    <message>
        <source>Change window title height</source>
        <translation type="vanished">修改标题栏高度</translation>
    </message>
    <message>
        <source>Reset to default</source>
        <translation type="vanished">重置为默认值</translation>
    </message>
    <message>
        <source>Apply</source>
        <translation type="vanished">应用</translation>
    </message>
    <message>
        <location filename="../main.qml" line="16"/>
        <source>System Environment</source>
        <translation>系统环境变量</translation>
    </message>
    <message>
        <location filename="../main.qml" line="17"/>
        <source>change system environment for user</source>
        <translation>修改用户的系统环境变量</translation>
    </message>
    <message>
        <location filename="../main.qml" line="117"/>
        <source>Please modify environment variables carefully.You must clearly understand the importance of system environment variables. This operation is irreversible.If there is a problem, please log in with tty and delete the $HOME/.dde_env file to restore the environment. Please login again to apply changes.</source>
        <translation>请慎重修改环境变量，您必须明确知道系统环境变量的重要性。该操作不可逆，如果出现问题，请在 tty 登录，并删除 $HOME/.dde_env 文件来恢复环境。请重新登录来应用变更。</translation>
    </message>
    <message>
        <location filename="../main.qml" line="126"/>
        <source>Add</source>
        <translation>添加</translation>
    </message>
    <message>
        <location filename="../main.qml" line="145"/>
        <source>Save</source>
        <translation>保存</translation>
    </message>
</context>
</TS>
