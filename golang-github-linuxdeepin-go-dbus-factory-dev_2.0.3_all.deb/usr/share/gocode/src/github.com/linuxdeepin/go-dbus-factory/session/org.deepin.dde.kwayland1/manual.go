// SPDX-FileCopyrightText: 2018 - 2023 UnionTech Software Technology Co., Ltd.
//
// SPDX-License-Identifier: GPL-3.0-or-later

package kwayland1

// Rect type
type Rect struct {
	X, Y, Width, Height int32
}
