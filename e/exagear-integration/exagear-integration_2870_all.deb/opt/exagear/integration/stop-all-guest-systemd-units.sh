#!/bin/bash

if [ -z "${EXAGEAR_GUEST_WRAP_MARKER}"  ]
then
	echo "ERROR: variable EXAGEAR_GUEST_WRAP_MARKER is not set."
	exit 1
fi

ALL_STARTED_SYSTEMD_UNITS=`systemctl list-units --runtime --no-pager | grep 'running' | egrep '\.service' | awk '{print $1}' `

for S in ${ALL_STARTED_SYSTEMD_UNITS}
do
	if systemctl cat ${S} | grep ${EXAGEAR_GUEST_WRAP_MARKER} > /dev/null 2>&1
	then
		systemctl stop ${S}
	fi
done
