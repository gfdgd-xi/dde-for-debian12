// SPDX-FileCopyrightText: 2018 - 2022 UnionTech Software Technology Co., Ltd.
//
// SPDX-License-Identifier: GPL-3.0-or-later

#ifndef __THUMBNAIL_H__
#define __THUMBNAIL_H__

int font_thumbnail(char* file, char* dest, int size);

#endif
