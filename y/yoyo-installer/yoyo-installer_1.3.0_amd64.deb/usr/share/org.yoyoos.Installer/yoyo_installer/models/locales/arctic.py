from yoyo_installer.core.locale import Locale

name = "arctic"
locales = [
  Locale(
    region="Arctic",
    location="Longyearbyen",
    locales="no_NO.UTF-8 UTF-8",
  )
]
