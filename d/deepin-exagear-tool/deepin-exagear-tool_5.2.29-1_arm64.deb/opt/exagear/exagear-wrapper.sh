#!/bin/bash

FD_LIMIT=$((`ulimit -Hn` - 16))
EXAGEAR_PATH="/opt/exagear/bin"
IMAGE_PATH="/opt/deepinwine/runtime-i386"
CMD="$EXAGEAR_PATH/ubt_x64a64_al"
ARGS="--smo-mode fbase --smo-severity smart --bolt-socket /tmp/.exagear.bolt.socket --hifd-start $FD_LIMIT --path-prefix $IMAGE_PATH --vpaths-list $IMAGE_PATH/.exagear/vpaths-list --opaths-list $IMAGE_PATH/.exagear/opaths-list --utmp-paths-list $IMAGE_PATH/.exagear/utmp-list --use-binfmt_misc --foreign-ubt-binary $EXAGEAR_PATH/ubt_x32a64_al -- "

if [ "$1" = "deepin-wine6-stable" ];then
    "$@"
else
    "$CMD" $ARGS "$@"
fi

