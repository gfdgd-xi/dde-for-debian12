#define RARVER_MAJOR     5
#define RARVER_MINOR    61
#define RARVER_BETA      1
#define RARVER_DAY       3
#define RARVER_MONTH     9
#define RARVER_YEAR   2018
