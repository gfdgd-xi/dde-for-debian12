#ifndef TENNIS_API_CPP_TENSORSTACK_H
#define TENNIS_API_CPP_TENSORSTACK_H

#pragma message("Using decrepted header, please use #include \"api/cpp/tennis.h\" instead")

#include "tennis.h"

#endif //TENNIS_API_CPP_TENSORSTACK_H
